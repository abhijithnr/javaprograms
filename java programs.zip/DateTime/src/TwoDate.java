import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;


public class TwoDate {
	public static void main(String [] args){
		LocalDate date1=null;
		try{
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			Scanner scanner = new Scanner(System.in);
			System.out.print("Enter date in dd/MM/yyyy format:");
			String input  = scanner.nextLine();
			 date1 = LocalDate.parse(input,formatter);

			System.out.println("Entered Date:"+ date1);
			}
			catch(Exception e)
			{
				System.out.println("Please enter the date in mentioned format only...");
				
			}
		LocalDate date2=null;
		try{
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			Scanner scanner = new Scanner(System.in);
			System.out.print("Enter date in dd/MM/yyyy format:");
			String input  = scanner.nextLine();
			 date2 = LocalDate.parse(input,formatter);

			System.out.println("Entered Date:"+ date2);
			scanner.close();
			}
			catch(Exception e)
			{
				System.out.println("Please enter the date in mentioned format only...");
				
			}
		Period period=date1.until(date2);
		System.out.println("Days:"+ period.getDays());
		System.out.println("Months:"+period.getMonths());
		System.out.println("Years:"+ period.getYears());
		
		
	}

}
