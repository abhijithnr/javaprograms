import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;


public class Warantee {
	public static void main(String [] args){
		LocalDate pdate= null;
		try{
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			Scanner scanner = new Scanner(System.in);
			System.out.print("Enter date in dd/MM/yyyy format:");
			String input  = scanner.nextLine();
			 pdate = LocalDate.parse(input,formatter);

			System.out.println("Entered Date:"+ pdate);
			System.out.println("Enter months of warranty");
			int months=scanner.nextInt();
			System.out.println("Entered Month is:"+ months);
			System.out.println("Enter Years of warranty");
			int years=scanner.nextInt();
			System.out.println("Entered Year is :"+ years);
			
			LocalDate expiry =pdate.plusMonths(months);
			 expiry =pdate.plusYears(years);
			System.out.println("Days:"+ pdate.getDayOfMonth());
			System.out.println("Months:"+expiry.getMonth());
			System.out.println("Years:"+ expiry.getYear());
			}
			catch(Exception e)
			{
				System.out.println("Please enter the date in mentioned format only...");
				
			}
	
		
		
		
	}

}
