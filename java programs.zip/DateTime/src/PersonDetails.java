import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

class person
{
	private String fname;
	private String lname;
	private char gender;
	public person() {

	}
	public person(String fname, String lname, char gender) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.gender = gender;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	
	
}

public class PersonDetails {
 Period calculateAge(LocalDate date2)
	{
		LocalDate date3=LocalDate.now();
		Period period=date2.until(date3);
		return period;
					
	}
  String getFullName(String firstName, String lastName) 
 {
	 String fullname=firstName+lastName;
	 return fullname;
 }
public static void main(String []args)
{
	LocalDate date1=null;
	try{
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter date of birth in dd/MM/yyyy format:");
		String input  = scanner.nextLine();
		 date1 = LocalDate.parse(input,formatter);

		System.out.println("Entered Date:"+ date1);
		
		}
		catch(Exception e)
		{
			System.out.println("Please enter the date in mentioned format only...");
			
		}
	Period age=new PersonDetails().calculateAge(date1);
	System.out.println("Age is"+age.getYears()+" "+age.getMonths()+" "+age.getDays());
	System.out.println("Enter first name");
	Scanner scanner = new Scanner(System.in);
	String fname=scanner.nextLine();
	System.out.println("Enter first name");
	String lname=scanner.nextLine();
	String ffname=new PersonDetails().getFullName(fname,lname);
	System.out.println("The full name is "+ffname);
	
	
	
}
}
