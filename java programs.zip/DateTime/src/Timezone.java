import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;


public class Timezone {
	public static void main (String [] args){
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the time zone");
		String timezone=scanner.nextLine();
		System.out.println("The time zone you have entered is" +timezone);
		ZonedDateTime currentTime = ZonedDateTime.now();
		ZonedDateTime timeinspecifiedzone=currentTime.withZoneSameInstant(ZoneId.of(timezone));
		System.out.println("Time in specified zone is"+timeinspecifiedzone);
		
	}

}
