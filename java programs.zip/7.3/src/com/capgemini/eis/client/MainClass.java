package com.capgemini.eis.client;

import com.capgemini.eis.bean.Employee;
import com.capgemini.eis.pl.EmployeePresentation;

public class MainClass {

	public static void main(String[] args) {
		Employee employee=EmployeePresentation.inputDetails();
	employee.setInsuranceScheme(EmployeePresentation.insurance(employee));
	EmployeePresentation.displayEmployeeDetails(employee);

		
		
	}

}
