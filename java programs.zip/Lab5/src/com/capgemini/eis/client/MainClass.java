package com.capgemini.eis.client;

import com.capgemini.eis.bean.Employee;
import com.capgemini.eis.pl.EmployeePresentation;

public class MainClass {

	public static void main(String[] args) {
		Employee employee1=EmployeePresentation.inputDetails();
	employee1.setInsuranceScheme(EmployeePresentation.insurance(employee1));
	EmployeePresentation.displayEmployeeDetails(employee1);

		
		
	}

}
