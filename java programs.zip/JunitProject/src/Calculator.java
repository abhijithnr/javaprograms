
public class Calculator {
	public int divide(int number)
	{
		return (100/number);
		
	}

}
