import java.util.HashMap;
import java.util.*;


public class Testhashmapdemo {

	public static void main(String[] args) {
HashMap<Long,String> directory=new HashMap<Long,String>();
directory.put(88888L, "Abn");
directory.put(88887L, "An");
directory.put(88886L, "bn");
directory.put(88885L, "Abcn");
directory.put(88884L, "Abdn");
System.out.println(directory);
System.out.println("****print Entries*****");
Set<Map.Entry<Long,String >>mapSet=directory.entrySet();
Iterator<Map.Entry<Long, String>>it=mapSet.iterator();
while(it.hasNext())
{
	Map.Entry<Long, String> entry=it.next();
	System.out.println("Key:"+entry.getKey()+"name:"+entry.getValue());
}
System.out.println("***print keys ****");
Set<Long>kSet=directory.keySet();
Iterator<Long>itk=kSet.iterator();
while(itk.hasNext())
{
	Long key=itk.next();
	System.out.println("Key:"+key);
}
System.out.println("***print value ****");
Collection<String>values=directory.values();
Iterator<String>ity=values.iterator();
while(itk.hasNext())
{
	String value=ity.next();
	System.out.println("Value:"+value);
}
	}

}
