
import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;
public class TreeSetDemo {
	public static void main(String[] args) {
		TreeSet <Integer> intList=new  TreeSet<Integer>();
		Integer i1= new Integer(40);
		Integer i2= new Integer(30);
		Integer i3= new Integer(420);
		Integer i4= new Integer(40);
		String str4=new String("abn");
		intList.add(i1);
		intList.add(i2);
		intList.add(i3);
		intList.add(i4);

		Iterator it=intList.iterator();
		while(it.hasNext())
		{
			Integer ii=(int)it.next();
			System.out.println("Entry:"+ii);
		}
		
		}
}
