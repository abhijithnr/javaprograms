package com.cg.eis.service;
import com.cg.eis.bean.Employee;

import java.util.Collection;
import java.util.HashMap;
import java.util.Scanner;

public class EmployeeServiceImpl {

		static HashMap<String,Employee> employeelist = new HashMap<String,Employee>();  
			
		public static void addEmployee(Employee employee)	{
				//code to add employee
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter the insurance scheme");
			String insurancescheme=sc.next();
			employee.setInsuranceScheme(insurancescheme);
			employeelist.put(insurancescheme,employee);
			
		}
		public static boolean deleteEmployee(int id)	{
			Employee toDelete=null;
			int flag=0;
			Collection<Employee> values=employeelist.values();
			for(Employee emp:values)
			{
				if(emp.getId()==id)
				{
					toDelete=emp;
					flag=1;
					break;
				}

			}
			if(flag==1)
			{
				employeelist.remove(toDelete.getInsuranceScheme(),toDelete);
				return true;
			}
			else 
				return false;
			
			}
		public static void main(String args[]){
			Scanner sc=new Scanner(System.in);

			
		}

		}




