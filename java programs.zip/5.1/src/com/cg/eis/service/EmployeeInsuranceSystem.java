package com.cg.eis.service;
public interface EmployeeInsuranceSystem {

	static void display(String Name) {
		// TODO Auto-generated method stub
		
	}
	

}