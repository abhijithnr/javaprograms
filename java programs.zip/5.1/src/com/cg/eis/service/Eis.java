package com.cg.eis.service;

public class Eis implements EmployeeInsuranceSystem {
	public void display(String Name)
	{
		System.out.println("Scheme is "+Name);
	}

}
