import java.util.Scanner;

import com.cg.eis.service.EmployeeInsuranceSystem;

import com.cg.eis.service.*;
public class Employee2 {
	private float salary;
	private String designation;
	private String scheme;
	public Employee2() {

		
	}
	public Employee2(float salary, String designation, String scheme) {
		super();
		this.salary = salary;
		this.designation = designation;
		this.scheme = scheme;
	}
	

public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getScheme() {
		return scheme;
	}
	public void setScheme(String scheme) {
		this.scheme = scheme;
	}
	
	public static void main (String args[])
	{
	Employee2 e =new Employee2();
		System.out.println("Enter the Salary");
		Scanner sc=new Scanner(System.in);
		int setSalary=sc.nextInt();
		if((e.salary > 5000 && e.salary<20000)  )
		{
			e.setScheme("Scheme C");
			e.setDesignation("System Associate");
			//System.out.println("Scheme is:"+e.scheme);
			System.out.println("Designation :"+e.designation);

		}
		else if((e.salary>=20000 && e.salary<40000) )
		{
			e.setScheme("Scheme B");
			e.setDesignation("Programmer");
			EmployeeInsuranceSystem.display(e.scheme);
			//System.out.println("Scheme is:"+e.scheme);
			System.out.println("Designation :"+e.designation);

		}
		else if((e.salary>=40000))
		{
			e.setScheme ("Scheme A");
			e.setDesignation("Manager");
			//System.out.println("Scheme is:"+e.scheme);
			System.out.println("Designation :"+e.designation);

		}

			else if((e.salary<5000 ) )
			{
				e.setScheme("No Scheme");
				e.setDesignation("Clerk");
				//System.out.println("Scheme is:"+e.scheme);
				System.out.println("Designation :"+e.designation);

			}
		}
	
	
		
		

		
}

