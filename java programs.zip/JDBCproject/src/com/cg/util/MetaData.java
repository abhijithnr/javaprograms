package com.cg.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class MetaData {
	public static void main(String[] args) throws SQLException  {
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		ResultSetMetaData rsmd=null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			 con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:orcl11g","lab1btrg20","lab1boracle");
			 st=con.createStatement();
			rs=st.executeQuery("Select * FROM emp_158009");
			System.out.println("------result set meta data");
			 rsmd=rs.getMetaData();
			 int colCount=rsmd.getColumnCount();
			 System.out.println("No.of Columns"+colCount);
			 for(int i=1;i<=colCount;i++)
			 {
				 System.out.println("Column Name:"+rsmd.getColumnName(i)+"Column Type:"+rsmd.getColumnTypeName(i));
			 }
			
			while(rs.next())
			{
				System.out.println(":"+rs.getInt("EMP_ID")+":"+rs.getString("EMP_NAME")+":"+rs.getInt("EMP_SALARY"));
			}
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

