package com.cg.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class TestEmpSelectDemo2 {

	public static void main(String[] args) throws SQLException {
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		PreparedStatement pst=null;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Min Salary");
		int minSal=sc.nextInt();
		System.out.println("Enter Max Salary");
		int maxSal=sc.nextInt();
		
		String qry="SELECT * FROM emp_158009 where emp_salary>=? and emp_salary<=?";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			 con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:orcl11g","lab1btrg20","lab1boracle");
			 pst=con.prepareStatement(qry);
			 pst.setInt(1,minSal);
			 pst.setInt(2,maxSal);
			rs=pst.executeQuery();
			while(rs.next())
			{
				System.out.println(":"+rs.getInt("EMP_ID")+":"+rs.getString("EMP_NAME")+":"+rs.getInt("EMP_SALARY"));
			}
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
