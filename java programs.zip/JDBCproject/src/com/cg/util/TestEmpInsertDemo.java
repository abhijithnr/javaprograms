package com.cg.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class TestEmpInsertDemo {

	public static void main(String[] args) throws SQLException {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter id");
		int empId=sc.nextInt();
		System.out.println("enter name");
		String empName=sc.next();
		System.out.println("enter salary");
		int empSalary=sc.nextInt();

		String query="insert into emp_158009 values(?,?,?)";
		PreparedStatement pst=null;
		Connection con=null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			 con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:orcl11g","lab1btrg20","lab1boracle");
			 pst=con.prepareStatement(query);
			 pst.setInt(1, empId);
			 pst.setString(2, empName);
			 pst.setInt(3, empSalary);
			 int noOfrecAffected=pst.executeUpdate();
			 System.out.println(noOfrecAffected+"data inserted in table");
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}

}
