package com.cg.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class DeleteEmployee {

	public static void main(String[] args) throws SQLException {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter id");
		int empId=sc.nextInt();
		String query="delete from emp_158009 where emp_Id=?";
		PreparedStatement pst=null;
		Connection con=null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			 con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:orcl11g","lab1btrg20","lab1boracle");
			 pst=con.prepareStatement(query);
			 pst.setInt(1, empId);
			 int noOfrecAffected=pst.executeUpdate();
			 System.out.println(noOfrecAffected+"data deleted from table");
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
