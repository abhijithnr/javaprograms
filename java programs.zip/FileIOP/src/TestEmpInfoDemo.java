import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;




public class TestEmpInfoDemo {

	public static void main(String[] args) {
		File myFile=new File("D:/Abhijith/FileIOP/src/TestEmpReadDemo.java");
		FileInputStream fis=null;
		try {
			 fis=new FileInputStream(myFile);
			int data=fis.read();
			while(data!=-1){
				System.out.print((char)data);
				data=fis.read();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
		

	}


