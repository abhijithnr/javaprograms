import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;


public class TestPropsWriteDemo {

	public static void main(String[] args) {
		FileOutputStream fos=null;
		Properties myDbInfo=null;
try {
	 fos=new FileOutputStream("dbInfo.properties");
	 myDbInfo=new Properties();
	 myDbInfo.setProperty("dBuser", "System");
	 myDbInfo.setProperty("dbPed", "Root");
	 myDbInfo.store(fos, "This is the data base info");
	 System.out.println("Data written iin file");
} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

	}

}
