
public class MyThread2Main {

	public static void main(String[] args) {
		Thread thread=new Thread(new MyThread2());
		for(int i=1;i<=10;i++){
			System.out.println("Mani i"+i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(i==5)
				try {
					thread.join();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

	}

}
