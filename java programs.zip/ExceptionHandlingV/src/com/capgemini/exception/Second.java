package com.capgemini.exception;
import com.capgemini.bean.*;

public class Second {
	
	
	public static void main(String args[])
	{
		Person ram=new Person();
		ram.setName("Ram");
		ram.setAge(14);
		try {
		check(ram);
Account acc1=new Account(10001, 2000, ram);
		
		acc1.deposit(200);
		acc1.getBalance();
		acc1.withdraw(684);
		acc1.getBalance();
		}
		catch(AgeException e)
		{
			System.out.println("Account could not be opened  " +e);
		}
		finally
		{
			System.out.println("Application  Ended");
		}
		
		
	}

	private static void check(Person ram) throws AgeException {
		if(ram.getAge()<15)
			throw new AgeException(ram.getAge());
		
	}
}
