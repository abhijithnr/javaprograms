package com.capgemini.exception;

public class AgeException extends Exception{
	private float age;
	AgeException(float a) {
	age = a; }
	
	public String toString() {
	return age+" Enter valid age";
	}
}
