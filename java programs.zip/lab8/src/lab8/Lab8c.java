package lab8;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Scanner;

class Employee implements Serializable
{
	int empid;
	String ename;
	float salary;
	
	public Employee() {

	}
	
	public Employee(int empid, String ename, float salary) {
		super();
		this.empid = empid;
		this.ename = ename;
		this.salary = salary;
	}

	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", ename=" + ename + ", salary="
				+ salary + "]";
	}
	
	}

public class Lab8c {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		int num;
		FileOutputStream fos=null;
		ObjectOutputStream oos=null;
		fos=new FileOutputStream("EmpObj.obj");
		 oos=new ObjectOutputStream(fos);
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of employees");
		 num=sc.nextInt();
		 Employee e1=new Employee();
		 for(int i=0;i<num;i++){
		System.out.println("Enter emp id");
		 e1.empid=sc.nextInt();
		System.out.println("Enter name");
		 e1.ename=sc.next();
		System.out.println("Enter sal");
		 e1.salary=sc.nextFloat();
		oos.writeObject(e1);
		 }
		 File myFile=new File("D:/Abhijith/lab8/EmpObj.obj");
			FileInputStream fis=null;
			ObjectInputStream ois=null;
			try {
				 fis=new FileInputStream(myFile);
				 ois=new ObjectInputStream(fis);
				}
			 catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			for(int i=0;i<num;i++){
			Employee ee=(Employee)ois.readObject();
			System.out.println("Emp Info from file:"+ee);
			}
            
		
		
		
		
		

	}

}
