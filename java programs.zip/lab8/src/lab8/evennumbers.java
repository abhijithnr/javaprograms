package lab8;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class evennumbers {

	public static void main(String[] args) throws FileNotFoundException {
		File myFile=new File("D:/Abhijith/lab8/numbers");
		
		try {
			Scanner sc=new Scanner(myFile);

			String s=sc.nextLine();
			String values[]=s.split(",");
			for(int i=0;i<values.length;i++){
				if(Integer.parseInt(values[i])%2==0)
				{
					System.out.println(""+values[i]);
				}
				
			}


		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}

