package lab8;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class reverse {

	public static void main(String[] args) {
		File myFile=new File("D:/Abhijith/lab8/testreverse");
		FileReader fr=null;
		FileWriter fw=null;
		BufferedReader br=null;
		BufferedWriter bw=null;

		try {
			 fr=new FileReader(myFile);
			 br=new BufferedReader(fr);
			 fw=new FileWriter("Output.txt");
			 bw=new BufferedWriter(fw);
			 
			 String line=br.readLine();
			 StringBuffer str1=new StringBuffer(line);
			 str1.reverse();
			 while(line!=null){
				System.out.println(str1);
				bw.write(str1.toString());
				bw.flush();
				bw.write("\n");
				bw.flush();
				line=br.readLine();
				if(line!=null)
				{
					str1=new StringBuffer(line);
					str1.reverse();
				}
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}


