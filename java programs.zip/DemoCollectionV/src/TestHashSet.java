import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

public class TestHashSet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		HashSet<Integer> intList=new HashSet<Integer>(4);
		Integer i1=new Integer(10);
		Integer i2=new Integer(10);
		Integer i3=new Integer(30);
		Integer i4=new Integer(20);
		Integer i5=new Integer(40);
		String i6=new String("Heap");
		
		intList.add(i1);
		intList.add(i2);
		intList.add(i3);
		intList.add(i4);
		intList.add(i5);
		//intList.add(i6);
		
		Iterator<Integer> it=intList.iterator();
		while(it.hasNext())
		{
			System.out.println("Entry :" +it.next());
		}
		
	}

}
