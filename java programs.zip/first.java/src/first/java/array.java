package first.java;

import java.util.Scanner;

 class Empl {
	int empID;
	String Employee;
	float empSalary;
	public Empl() {

	}

	@Override
	public String toString() {
		return "array [empID=" + empID + ", Employee=" + Employee
				+ ", empSalary=" + empSalary + "]";
	}

	public Empl(int empID, String employee, float empSalary) {
		super();
		this.empID = empID;
		Employee = employee;
		this.empSalary = empSalary;
	}
	
	
	public static void main (String [] args){
		Scanner sc =new Scanner(System.in);
		System.out.println("How many emp");
		int empCount=sc.nextInt();
		Emp emps[]= new Emp[empCount];
		for(int i=0;i<emps.length;i++)
		{
			System.out.println("Enter Emp ID:");
			int eTD=sc.nextInt();
			System.out.println("Enter Emp name:");
			int eName=sc.nextInt();
			System.out.println("Enter Emp salary:");
			float eSal=sc.nextFloat();
			emps[i]=new Emp(112081,"ab",9000.0F);
			
		}
		
	}
	
	

}
