package first.java;

import java.util.ArrayList;
import java.util.Iterator;
 class Emp implements Comparable<Emp>
 {
	int empID;
	String Employee;
	float empSalary;
	
	public Emp(int empID, String employee, float empSalary) {
		super();
		this.empID = empID;
		Employee = employee;
		this.empSalary = empSalary;
	}
	@Override
	public String toString() {
		return "Emp [empID=" + empID + ", Employee=" + Employee
				+ ", empSalary=" + empSalary + "]";
	}
	public Emp() {

	}
}
public class TestArrayList {

	public static void main(String[] args) {
		ArrayList<Emp> empList=new ArrayList<Emp>();
		Emp e1=new Emp(112081,"ab",9000.0F);
		Emp e2=new Emp(112082,"ac",9000.0F);
		Emp e3=new Emp(112083,"cb",3000.0F);
		Emp e4=new Emp(112084,"bc",2000.0F);
		empList.add(e1);
		empList.add(e2);
		empList.add(e3);
		empList.add(e4);
		Iterator <Emp> itEmp=empList.iterator();
		while(itEmp.hasNext())
		{
			System.out.println("...."+itEmp.next());
		}

	}
}


