import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.Properties;
import java.util.Scanner;
import java.util.Set;


public class PropertiesWrite {
	public static void main(String[] args) {
	FileOutputStream fos=null;
	Properties myDbInfo=null;
	 System.out.println("Enter the total number of persons");
	 Scanner sc=new Scanner(System.in);
	 int num=sc.nextInt();
try {
 fos=new FileOutputStream("newFile.properties");
 myDbInfo=new Properties();

 for(int i=0;i<num;i++)
 {	 String name;
     String age;
     String gender;
	 System.out.println("Enter the name"); 
	 name=sc.next();
	 myDbInfo.setProperty("Name", name);
	 System.out.println("Enter the age");
	 age=sc.next();
     myDbInfo.setProperty("Age", age);
     System.out.println("Enter the gender");
     gender=sc.next();
     myDbInfo.setProperty("Gender", gender);
      myDbInfo.store(fos, "This is the data base info");
    
 }}
 catch (IOException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
 
System.out.println("Data written in file");
FileInputStream fis=null;
Properties myPros=null;
try {
	fis=new FileInputStream("newFile.properties");
  myPros=new Properties();
  myPros.load(fis);
  for(int i=1;i<=num;i++) {
  String name1;
  String age1;
  String gender1;
 
  name1=myPros.getProperty("Name");
  age1=myPros.getProperty("Age");
  gender1=myPros.getProperty("Gender");
  System.out.println("*********");
  System.out.println("DETAILS OF PERSON:"+name1+":"+age1+":"+gender1);

 }
 
} 
catch (IOException e) {
	e.printStackTrace();
}
	
}}
