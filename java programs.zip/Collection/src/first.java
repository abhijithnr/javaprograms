import java.util.Arrays;
import java.util.Scanner;


public class first {
public static void main(String [] Args){
System.out.println("Enter number of products");
Scanner sc= new Scanner(System.in);
int nos=sc.nextInt();
String products[]=new String[nos];
for(int n=0;n<nos;n++)
{
	System.out.println("Enter product name");
	 products[n]=sc.next();
}
Arrays.sort(products);
for(String i:products)
{
	System.out.println(i);
	}

}
}
