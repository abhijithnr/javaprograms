import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;


public class second {

	public static void main(String[] args) 
	{
		System.out.println("Enter number of products");
		Scanner sc= new Scanner(System.in);
		int nos=sc.nextInt();
ArrayList<String> intList=new ArrayList<String>(4);
for(int n=0;n<nos;n++)
{
	System.out.println("Enter product name");
     intList.add(sc.next());
     
}
Collections.sort(intList);
for(String x:intList)
{
	System.out.println(x);
}




	}

}
